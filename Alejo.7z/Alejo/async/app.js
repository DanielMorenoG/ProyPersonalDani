const axios=requiere('axios')
const pokeName='charmander'
const ApiUrl=`https://pokeapi.co/api/v2/pokemon/${pokeName}`

const pokeData= async()=>{
    try{
        const { data: pokemon } = await axios.get(apiUrl);
    const name = pokemon.name;
    const weight = pokemon.weight;
    const abilities = pokemon.abilities.map(a => a.ability.name);

    console.log(`Nombre: ${name}`);
    console.log(`Peso: ${weight}`);
    console.log(`Habilidades: ${abilities.join(', ')}`);


    const speciesUrl = pokemon.species.url;
    const { data: species } = await axios.get(speciesUrl);


    const evoChainUrl = species.evolution_chain.url;
    const { data: evoChainData } = await axios.get(evoChainUrl);


    function findNextEvolution(chain, currentName) {
      if (chain.species.name === currentName) {

        return chain.evolves_to[0]?.species.name || null;
      }

      for (const next of chain.evolves_to) {
        const found = findNextEvolution(next, currentName);
        if (found) return found;
      }
      return null;
    }

    const nextEvolution = findNextEvolution(evoChainData.chain, name);

    if (nextEvolution) {
      console.log(`Siguiente evolución: ${nextEvolution}`);
    } else {
      console.log('Este Pokémon no tiene evolución siguiente.');
    }

  } catch (error) {
    console.error('Error al obtener datos:', error.message);
  }
}

pokeData();